# Validação — branding Tem Link Aqui, 23/10/2026

Escopo: showroom local e arquivos de marca. Nenhum código de produto foi alterado.

Executado: geração SVG/PNG, verificação das dimensões PNG, parse e títulos dos SVGs, ausência de texto vivo/raster nos logos, cabeçalho ICO 16/32/48, auditoria da skill e inspeção dos quatro mockups. Símbolos: Ponte 99; Farol, Liga e Rota 100. Essas notas são heurísticas e não certificam qualidade, originalidade ou registro.

Brandbook: 11 páginas, PDF com texto extraível em todas as páginas; imagens carregadas e ausência de overflow nos quadros verificada. Renderização via PDFium para inspeção visual. A fonte Outfit e sua OFL estão incluídas. Imagens por IA e seus derivados têm origem e hashes em proveniencia.json.

A bateria específica do showroom está em showroom.spec.cjs, com configuração própria sem setup de backend ou containers. O relatório final do Playwright Test fica em validation/tests.json. Não rodamos lint/typecheck/build/E2E do produto, pois esta entrega não altera o frontend/backend da aplicação.

## Resultado do navegador

Playwright Test: **5 testes passaram**. Cobertura: 320, 390, 768 e 1440 px; troca das quatro identidades por Enter; `aria-pressed`, links de download e atualização de todas as artes; imagens decodificadas e links locais existentes; ausência de erros JavaScript e transbordamento. Axe WCAG 2 A/AA e 2.1 AA em 390 e 1440 px: nenhuma violação detectada. Isso não certifica acessibilidade total.

Verificados também reduced-motion, skip link, foco visível, ampliação **via CSS zoom de 200%** e favicon em modo claro/escuro. CSS zoom não equivale a um teste manual de zoom nativo em todos os navegadores. A ampliação revelou transbordamento; a responsividade passou a acompanhar o container real e o problema foi corrigido.

Playwright MCP em contexto próprio: navegação HTTP local, seleção de Farol em desktop e Liga em 390 px, captura e inspeção. A navegação `file:` é bloqueada pelo MCP, por isso foi usado servidor local somente de leitura, isolado da aplicação. O Playwright Test usa seus próprios contextos. Capturas desktop/mobile, zoom e páginas PDF foram abertas para inspeção, além da inspeção dos quatro mockups originais.

## Crítica e ferramentas

O inspector Taste encontrou um título de três linhas em tablet: encurtado para “Mesmas cores. Novas formas.”. A inspeção final usa três exceções documentadas: `still-page`, porque a comparação de forma/tamanho permanece estática e não há vídeo real de fabricação; `eyebrow`, falso positivo no aviso de simulação por IA abaixo da fotografia, que precisa permanecer; `icon-cards`, porque os quatro itens são controles de seleção com as próprias marcas, não cards decorativos de ícones.

Avisos de diversidade de tamanhos tipográficos e falta de vídeo são limites conhecidos do diagnóstico. Não adicionamos uma filmagem de estoque que sugerisse fabricação real. Essas exceções são decisões desta galeria, não novos contratos da home pública. Relatórios completos em research/taste/.

Artes físicas também exportadas em PNG **300 ppi**, com largura/altura e metadata verificadas. Arquivos permanecem RGB, sujeitos ao gabarito e à prova de cada fornecedor. ZIPs conferidos por integridade e existência dos membros.

Limites: não houve leitor de tela real, dispositivo físico, prova têxtil, arquivo de pontos de bordado, validação de impressão, pesquisa de registro de marca ou teste com público. Mockups são simulações e não substituem gabaritos dos fabricantes. A marca não foi aplicada ao site.

Reversão: remover somente a pasta branding/tem-link-aqui-2026-10-23 e seu registro de direção em .impeccable/surfaces/branding-showroom.md. As propostas anteriores e os assets em uso permanecem preservados.
